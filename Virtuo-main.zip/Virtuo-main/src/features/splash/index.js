export * from './splash.js';
